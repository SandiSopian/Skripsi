<?php

class Dyestuffmodel {
	private $table = 'dyestuff';
	private $db;

	public function __construct()
	{
		$this->db = new Database;
	}

	public function getAllDyestuff()
	{
		$this->db->query('SELECT * FROM ' . $this->table);
		return $this->db->resultSet();
	}

	public function getDyestuffById($id)
	{
		$this->db->query('SELECT * FROM ' . $this->table . ' WHERE id=:id');
		$this->db->bind('id', $id);
		return $this->db->single();
	}
 
	public function tambahDataDyestuff($data)
	{
		$query = "INSERT INTO dyestuff
		VALUES
		('', :nama, :jenis, :tanggal_loot, :stock)";

		$this->db->query($query);
		$this->db->bind('nama', $data['nama']);
		$this->db->bind('jenis', $data['jenis']);
		$this->db->bind('tanggal_loot', $data['tanggal_loot']);
		$this->db->bind('stock', $data['stock']);

		$this->db->execute();

		return $this->db->rowCount();
	}

	public function hapusDataDyestuff($id)
	{
		$query = "DELETE FROM dyestuff WHERE id = :id";
		$this->db->query($query);
		$this->db->bind('id', $id);

		$this->db->execute();

		return $this->db->rowCount();

	}
}