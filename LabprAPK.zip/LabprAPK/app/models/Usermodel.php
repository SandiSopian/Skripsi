<?php

class Usermodel {
	private $nama = 'Sandi';

	public function getUser()
	{
		return $this->nama;
	}

}