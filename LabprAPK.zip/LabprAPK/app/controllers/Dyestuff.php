<?php

class Dyestuff extends Controller{
	public function index()
	{
		$data['judul'] = 'Daftar Dyestuff';
		$data['dye'] = $this->model('Dyestuffmodel')->getALLDyestuff(); 
		$this->view('templates/header', $data);
		$this->view('dyestuff/index', $data);
		$this->view('templates/footer');
	}

	public function detail($id)
	{
		$data['judul'] = 'Detail Dyestuff';
		$data['dye'] = $this->model('Dyestuffmodel')->getDyestuffById($id); 
		$this->view('templates/header', $data);
		$this->view('dyestuff/detail', $data);
		$this->view('templates/footer');
	} 

	public function tambah()
	{
		if( $this->model('Dyestuffmodel')->tambahDataDyestuff($_POST) > 0 ) {
			Flasher::setFlash('berhasil', 'ditambahkan', 'success');
			header('Location: ' . BASEURL . '/dyestuff');
			exit;
		} else {
			Flasher::setFlash('gagal', 'ditambahkan', 'danger');
			header('Location: ' . BASEURL . '/dyestuff');
			exit;
		}
	}

	public function hapus($id)
	{
		if( $this->model('Dyestuffmodel')->hapusDataDyestuff($id) > 0 ) {
			Flasher::setFlash('berhasil', 'dihapus', 'success');
			header('Location: ' . BASEURL . '/dyestuff');
			exit;
		} else {
			Flasher::setFlash('gagal', 'dihapus', 'danger');
			header('Location: ' . BASEURL . '/dyestuff');
			exit;
		}
	}
}