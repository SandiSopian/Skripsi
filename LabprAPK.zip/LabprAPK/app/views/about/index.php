<div class="container">
	<h1 class="mt-4">About</h1>
	<img src="<?= BASEURL; ?>/img/profile.jpg" alt="Lab printing" width="200" class="rounded-circle shadow">
	<p>Halo, nama saya <?= $data['nama']; ?>, saya seorang <?= $data['pekerjaan']; ?></p>
</div> 